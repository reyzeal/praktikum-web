<!DOCTYPE html>
<html>
<head>
	<title>Form Login</title>
</head>
<body>
<form method="POST" action="login_proses.php">
	<table>
		<tr>
			<td> Username </td>
			<td> : </td>
			<td> <input type="text" name="user"> </td>
		</tr>
		<tr>
			<td> Password </td>
			<td> : </td>
			<td> <input type="password" name="pass"> </td>
		</tr>
		<tr>
			<td rowspan="3"> <input type="submit" name="simpan" value="Simpan"> </td>
		</tr>
	</table>
</form>
</body>
</html>